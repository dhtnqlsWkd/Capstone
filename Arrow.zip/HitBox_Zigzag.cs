﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class HitBox_Zigzag : MonoBehaviour, IDamageable
{
    public Text m_ScoreText;
    public static int score = 0;
    public float health = 100.0f;
    System.Random rd = new System.Random();

    private int x;
    private int y;
    private int flag;

    void Start()
    {
        x = rd.Next(45, 79);
        y = 1; //rd.Next(1, 9);
        transform.position = new Vector3(x, y, 70);

        flag = 1;
    }

    void Update()
    {
        if (transform.position.z <= 34)
        {
            //gameObject.SetActive(false);
            MakeHitBox.ReduceLife();
            Destroy(gameObject);
        }

        if (flag == 1)
            transform.Translate(-0.07f, 0.0f, 0.07f);
        if (flag == 1 && transform.position.x <= x - 3)
            flag = 0;

        if (flag == 0)
            transform.Translate(0.07f, 0.0f, 0.07f);
        if (flag == 0 && transform.position.x >= x + 3)
            flag = 1;

        if (MakeHitBox.CheckLife())
            Destroy(gameObject);
    }

    public void OnDamage(float damageAmount)
    {
        health -= damageAmount;

        if (health <= 0)
        {
            MakeHitBox.UpdateUI();
            Destroy(gameObject); // gameObject.SetActive(false);
        }
    }
}
