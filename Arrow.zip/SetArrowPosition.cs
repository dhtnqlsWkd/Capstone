﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetArrowPosition : MonoBehaviour
{
    public GameObject BowString;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(BowString.transform.position.x, BowString.transform.position.y, BowString.transform.position.z - 0.855f);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(BowString.transform.position.x, BowString.transform.position.y, BowString.transform.position.z - 0.855f);
    }
}
