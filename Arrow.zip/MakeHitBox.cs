﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class MakeHitBox : MonoBehaviour
{
    public GameObject m_hitbox;
    public GameObject m_hitbox_walk;
    public GameObject m_hitbox_run;
    public GameObject m_hitbox_zigzag;
    public float timer;
    public float criteria;
    public float walk_timer;
    public float walk_waitingTime;
    public float run_timer;
    public float run_waitingTime;
    public float zigzag_timer;
    public float zigzag_waitingTime;

    public Text m_BringLifeText;
    public Text m_BringScoreText;
    

    public static int life = 10;
    public static Text m_LifeText;
    public static int score = 0;
    public static Text m_ScoreText;
    // Start is called before the first frame update
    void Start()
    {
        timer = 0.0f;
        criteria = 20.0f;
        walk_timer = 0.0f;
        walk_waitingTime = 3.0f;
        run_timer = 0.0f;
        run_waitingTime = 12.0f;
        zigzag_timer = 0.0f;
        zigzag_waitingTime = 30.0f;

        m_LifeText = m_BringLifeText;
        m_ScoreText = m_BringScoreText;
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        walk_timer += Time.deltaTime;
        run_timer += Time.deltaTime;
        zigzag_timer += Time.deltaTime;

        if (timer > criteria && walk_waitingTime > 2.05f && run_waitingTime > 2.05f)
        {
            walk_waitingTime -= 0.1f;
            run_waitingTime -= 1.0f;
            if (criteria > 119)
                zigzag_waitingTime -= 5.0f;

            criteria += 20.0f;
        }

        if (walk_timer > walk_waitingTime)
        {
            //makeHitbox();
            makeHitbox_Walk();
            walk_timer = 0;
        }
        if (run_timer > run_waitingTime)
        {
            makeHitbox_Run();
            run_timer = 0;
        }
        //if (timer > 0 && zigzag_timer > zigzag_waitingTime)
        //{
        //    makeHitbox_Zigzag();
        //    zigzag_timer = 0;
        //}
    }

    private void makeHitbox()
    {
        Instantiate(m_hitbox);
    }

    private void makeHitbox_Walk()
    {
        if (CheckLife() == false)
            Instantiate(m_hitbox_walk);
    }

    private void makeHitbox_Run()
    {
        if (CheckLife() == false)
            Instantiate(m_hitbox_run);
    }

    private void makeHitbox_Zigzag()
    {
        if (CheckLife() == false)
            Instantiate(m_hitbox_zigzag);
    }

    public static void ReduceLife()
    {
        life--;
        m_LifeText.text = "Life : " + life.ToString();
    }

    public static bool CheckLife()
    {
        if (life <= 0)
            return true;
        return false;
    }

    public static void UpdateUI()
    {
        score += 1;
        m_ScoreText.text = "Score : " + score.ToString();
    }
}