﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class HitBox_Run : MonoBehaviour, IDamageable
{
    public Text m_ScoreText;
    public static int score = 0;
    public float health = 100.0f;
    System.Random rd = new System.Random();

    void Start()
    {
        int x = rd.Next(45, 79);
        int y = 1; //rd.Next(1, 9);
        transform.position = new Vector3(x, y, 70);
    }

    void Update()
    {
        if (transform.position.z <= 34)
        {
            //gameObject.SetActive(false);
            MakeHitBox.ReduceLife();
            Destroy(gameObject);
        }
        else
        {
            transform.Translate(0, 0, 0.07f);
        }

        if (MakeHitBox.CheckLife())
            Destroy(gameObject);
    }

    public void OnDamage(float damageAmount)
    {
        health -= damageAmount;

        if (health <= 0)
        {
            MakeHitBox.UpdateUI();
            Destroy(gameObject); // gameObject.SetActive(false);
        }
    }
}
